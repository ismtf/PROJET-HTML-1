window.onload = function () {

  function updateTotal() {
    const items = document.querySelectorAll('.item');
    let total = 0;
    items.forEach(item => {
      const price = parseInt(item.querySelector('.price').textContent);
      const qty = parseInt(item.querySelector('.qty').textContent);
      total += price * qty;
    });
    document.getElementById('total').textContent = total;
  }

  document.querySelectorAll('.plus').forEach(btn => {
    btn.addEventListener('click', () => {
      const qtySpan = btn.previousElementSibling;
      qtySpan.textContent = parseInt(qtySpan.textContent) + 1;
      updateTotal();
    });
  });

  document.querySelectorAll('.minus').forEach(btn => {
    btn.addEventListener('click', () => {
      const qtySpan = btn.nextElementSibling;
      let qty = parseInt(qtySpan.textContent);
      if (qty > 1) {
        qtySpan.textContent = qty - 1;
        updateTotal();
      }
    });
  });

  document.querySelectorAll('.delete').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.parentElement.remove();
      updateTotal();
    });
  });

  document.querySelectorAll('.like').forEach(btn => {
    btn.addEventListener('click', () => {
      btn.classList.toggle('liked');
      btn.textContent = btn.classList.contains('liked') ? '❤️' : '🤍';
    });
  });

  updateTotal();

};